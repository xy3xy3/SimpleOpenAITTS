使用bootstarp5+vue2+国内cdn完成一个文本转语音的框架
一个输入区，输入待转文本
一个选择区，选择音色
<label for="voice">音色选择</label>
                                <select class="form-control" id="voice" v-model="voice">
                                    <option value="alloy">Alloy</option>
                                    <option value="echo">Echo</option>
                                    <option value="fable">Fable</option>
                                    <option value="onyx">Onyx</option>
                                    <option value="nova">Nova</option>
                                    <option value="shimmer">Shimmer</option>
                                </select>
一个转换区，显示已转的文本，对应下载地址（存localstorage），有下载按钮和试听按钮
函数需要模拟请求当前路径?act=tts，返回code,msg,url