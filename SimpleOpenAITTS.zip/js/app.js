// app.js
new Vue({
    el: '#app',
    data: {
        text: '',
        voice: 'alloy',
        convertedText: '',
        audioUrl: ''
    },
    methods: {
        convertText() {
            // 限制转换后的文本最多为10个字符
            let textToConvert = this.text.slice(0, 10);
            this.convertedText = textToConvert + " (模拟转换音频)";
            this.audioUrl = "audio/demo.mp3"; // 模拟音频文件地址
            localStorage.setItem('convertedText', this.convertedText);
            localStorage.setItem('audioUrl', this.audioUrl);
        },        
        download() {
            const a = document.createElement('a');
            a.href = this.audioUrl;
            a.download = 'converted_audio.mp3';
            a.click();
        },
        listen() {
            const audio = new Audio(this.audioUrl);
            audio.play();
        }
    }
});
