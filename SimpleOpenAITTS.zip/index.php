<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text to Speech</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.0.0-beta1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div id="app" class="container mt-5">
        <div class="row mb-3">
            <!-- 输入区 -->
            <div class="col-md-6">
                <label for="text" class="form-label">输入待转文本</label>
                <textarea class="form-control" id="text" rows="3" v-model="text"></textarea>
            </div>

            <!-- 选择区 -->
            <div class="col-md-6">
                <label for="voice">音色选择</label>
                <select class="form-control" id="voice" v-model="voice">
                    <option value="alloy">Alloy</option>
                    <option value="echo">Echo</option>
                    <option value="fable">Fable</option>
                    <option value="onyx">Onyx</option>
                    <option value="nova">Nova</option>
                    <option value="shimmer">Shimmer</option>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <!-- 转换区 -->
            <button class="btn btn-primary" @click="convertText">转换文本</button>
            <div v-if="convertedText">
                <p>已转的文本: {{ convertedText }}</p>
                <button class="btn btn-success" @click="download">下载</button>
                <button class="btn btn-secondary" @click="listen">试听</button>
            </div>
        </div>

    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/vue/2.6.12/vue.min.js"></script>
    <script src="/js/app.js"></script>
</body>

</html>